import CapitalFinder from './components/CapitalFinder';
import Counter from './components/Counter';

const App = () => {
  return (
    <div>
      <Counter />
      <CapitalFinder />
    </div>
  );
};

export default App;
